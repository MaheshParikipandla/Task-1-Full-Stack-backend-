package com.example.demo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.constantss.LoggerMessage;
import com.example.demo.constantss.URLConstants;
import com.example.demo.exceptions.BadRequestException;

import com.example.demo.model.ApplicationAccess;

import com.example.demo.repository.AppsRepo;


@RestController
@CrossOrigin(origins = { URLConstants.CROSS_ORIGIN_URL })
public class AppController {
	@Autowired
	private AppsRepo apprepo;
	

	private static final Logger LOGGER = LoggerFactory.getLogger(AppController.class);

	@GetMapping(value = { URLConstants.APPLICATIONS_ACCESS_URL }, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ApplicationAccess>getAllApps() {

		LOGGER.info("Entering Application Access Controller");
		
		try {
			LOGGER.info(LoggerMessage.SUCCESS_MESSAGE);
			LOGGER.info(LoggerMessage.SUCCESSFULLY_FETCHED_APPS_MSG);

			return apprepo.getApps();
		} catch (BadRequestException e) {
			throw new BadRequestException(LoggerMessage.BAD_REQUEST, e);
		} catch (NullPointerException e) {
			throw new NullPointerException(LoggerMessage.GET_APPLICATIONS_NULL_POINTER_EXCEPTION);
		}

	}

	
	
	
	@PostMapping("/saveApps")
	public String saveApps(@RequestBody ApplicationAccess apps) {
		apprepo.saveApps(apps);
		return "success";
	}
//	@GetMapping("/getAllApps")
//	public List<ApplicationAccess>getAllApps() {
//		return apprepo.getApps();
//	}
}
