package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="assignedadmins")
public class Admins {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String admin;
	private String Signin;
	
	
	public Admins() {}
	
	
    public Admins(int id,String Admin, String Signin) {
        
        this.id = id;
        this.admin = Admin;
        this.Signin=Signin;
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAdmin() {
		return admin;
	}

	public void setAdmin(String admin) {
		this.admin = admin;
	}


	public String getSignin() {
		return Signin;
	}


	public void setSignin(String signin) {
		Signin = signin;
	}


	@Override
	public String toString() {
		return "Admins [id=" + id + ", admin=" + admin + ", Signin=" + Signin + "]";
	}

	
    
	
	

}

