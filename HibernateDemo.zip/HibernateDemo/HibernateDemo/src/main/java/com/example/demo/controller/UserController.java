package com.example.demo.controller;
//com.example.demo.constantss.LoggerMessage;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.constantss.URLConstants;
import com.example.demo.constantss.LoggerMessage;
import com.example.demo.exceptions.BadRequestException;
//import com.example.demo.Controller.RolesController;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@RestController
@CrossOrigin(origins = { URLConstants.CROSS_ORIGIN_URL })
public class UserController {
	private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserRepository repo;
	
	@PostMapping(value="/saveUser")
	public String save(@RequestBody User user) {
		repo.saveUser(user);
		return "success";
	}
	@GetMapping(value="/userroles", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<User> getAllUsers() {
		
		try {			
			LOGGER.info(LoggerMessage.SUCCESS_MESSAGE);
			LOGGER.info(LoggerMessage.SUCCESSFULLY_FETCHED_USERS_MSG);
			return repo.getUsers();

		} catch (BadRequestException e) {
			throw new BadRequestException(LoggerMessage.BAD_REQUEST, e);
		} catch (NullPointerException e) {
			throw new NullPointerException(LoggerMessage.USER_ROLES_NULL_POINTER_EXCEPTION);
		}

		
	}


}
