package com.example.demo.constantss;



public interface URLConstants {
	
    public String CROSS_ORIGIN_URL="http://localhost:3000";
	
	public String USER_ROLES_URL="/userroles";
	
	public String APPLICATIONS_ACCESS_URL="/applicationaccess";
	
	public String ASSIGNED_ADMINS="/assignedadmins";
	
	public String SPECIFIC_USER_ROLES_URL="/userroles/{role}";
	

}
