package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="applicationacces")
public class ApplicationAccess {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String apps;
	
	public  ApplicationAccess()
	{
		
	}
	  public ApplicationAccess(int id,String apps) {
	        
	        this.id = id;
	    
	        this.apps=apps;
	    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getApps() {
		return apps;
	}

	public void setApps(String apps) {
		this.apps = apps;
	}

	@Override
	public String toString() {
		return "ApplicationAccess [id=" + id + ", apps=" + apps + "]";
	}
	

}
