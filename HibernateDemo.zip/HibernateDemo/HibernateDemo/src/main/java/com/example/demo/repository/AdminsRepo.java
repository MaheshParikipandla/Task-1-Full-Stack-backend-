package com.example.demo.repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Admins;
import com.example.demo.model.User;

@Repository
@Transactional
@EnableAutoConfiguration(exclude=HibernateJpaAutoConfiguration.class)
public class AdminsRepo {
	@Autowired
	private SessionFactory factory;

	public void saveAdmins(Admins admin) {
		getSession().save(admin);
	}

	@SuppressWarnings("unchecked")
	public List<Admins> getAdmins() {
		return getSession().createCriteria(Admins.class).list();
	}

	private Session getSession() {
		Session session = factory.getCurrentSession();
		if (session == null) {
			session = factory.openSession();
		}
		return session;
	}
}
