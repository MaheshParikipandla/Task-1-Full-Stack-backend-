package com.example.demo.repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.example.demo.model.User;

@Repository
@Transactional
@EnableAutoConfiguration(exclude=HibernateJpaAutoConfiguration.class)
public class UserRepository {
	@Autowired
	private SessionFactory factory;

	public void saveUser(User user) {
		getSession().save(user);
	}

	@SuppressWarnings("unchecked")
	public List<User> getUsers() {
		return getSession().createCriteria(User.class).list();
	}

	private Session getSession() {
		Session session = factory.getCurrentSession();
		if (session == null) {
			session = factory.openSession();
		}
		return session;
	}
//	public static SessionFactory getSessionFactory() {
//	      if (sessionFactory == null) {
//	         try {
//	            StandardServiceRegistryBuilder registryBuilder = 
//	                  new StandardServiceRegistryBuilder();
//
//	            Map<String, Object> settings = new HashMap<>();
//	            settings.put(Environment.DRIVER, "com.mysql.cj.jdbc.Driver");
//	            settings.put(Environment.URL, "jdbc:mysql://localhost:3306/demodb");
//	            settings.put(Environment.USER, "user");
//	            settings.put(Environment.PASS, "password");
//	            settings.put(Environment.HBM2DDL_AUTO, "update");
//	            settings.put(Environment.SHOW_SQL, true);
//
//	            // HikariCP settings
//	            
//	            // Maximum waiting time for a connection from the pool
//	            settings.put("hibernate.hikari.connectionTimeout", "20000");
//	            // Minimum number of ideal connections in the pool
//	            settings.put("hibernate.hikari.minimumIdle", "10");
//	            // Maximum number of actual connection in the pool
//	            settings.put("hibernate.hikari.maximumPoolSize", "20");
//	            // Maximum time that a connection is allowed to sit ideal in the pool
//	            settings.put("hibernate.hikari.idleTimeout", "300000");
//
//	            registryBuilder.applySettings(settings);
//
//	            registry = registryBuilder.build();
//	            MetadataSources sources = new MetadataSources(registry)
//	                  .addAnnotatedClass(Person.class);
//	            Metadata metadata = sources.getMetadataBuilder().build();
//	            sessionFactory = metadata.getSessionFactoryBuilder().build();
//	         } catch (Exception e) {
//	            if (registry != null) {
//	               StandardServiceRegistryBuilder.destroy(registry);
//	            }
//	            e.printStackTrace();
//	         }
//	      }
//	      return sessionFactory;
//	}
}
