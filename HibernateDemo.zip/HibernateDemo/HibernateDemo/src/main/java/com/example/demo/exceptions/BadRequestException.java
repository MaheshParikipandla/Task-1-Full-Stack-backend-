package com.example.demo.exceptions;


import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;
@ResponseStatus(value=HttpStatus.NOT_FOUND) 
public class BadRequestException extends RuntimeException {
    public BadRequestException(String message, Integer id) {
        super(message);
    }

    public BadRequestException(String BadRequestExceptionMessage, Exception e) {
        super(BadRequestExceptionMessage);
    }

	public BadRequestException(String badRequest, String role) {
		// TODO Auto-generated constructor stub
        super(badRequest);
	}
}