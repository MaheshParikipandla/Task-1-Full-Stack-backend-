package com.example.demo.constantss;

public interface LoggerMessage {

	String SUCCESS = "SUCCESS";
	String FAILURE = "FAILURE";

	int INTERNAL_SERVER_ERROR = 500;
	String BAD_REQUEST = "The request was unsuccessful for specific User";
	String DATA_ACCESS_ERROR_MSG = "Unable to Fetch data From server";
	String NO_DATA_FOUND = "Error 404, Data Not found";
	String REQUEST_TIMEOUT_ERROR_MSG = "Request Time Out";
	String INTERNAL_SERVER_ERROR_MSG = "Something went wrong";

//	 Success messages
	public String SUCCESS_MESSAGE = "The request was successful.";
	String SUCCESSFULLY_FETCHED_USERS_MSG = "User Roles retrived Successfully";
	String SUCCESSFULLY_FETCHED_USER_MSG = "User Apps Data retrived Successfully";
	String SUCCESSFULLY_FETCHED_APPS_MSG = "Applications retrived Successfully";
	String SUCCESSFULLY_FETCHED_ADMINS_MSG = "Admins retrived Successfully";

	String EXCEPTIONS_MSG = "Exception occured in method";
	String UNSUCCESSFUL_FETCHING_APPS_MSG = "Couldn't retrieve the requested data";

//	 user roles
	public String USER_ROLES_NULL_POINTER_EXCEPTION = "No Users Details found";
	public String GET_USER_ROLES_NULL_POINTER_EXCEPTION = "User Not found";
//	Apps
	public String GET_APPLICATIONS_NULL_POINTER_EXCEPTION = "No Applications Found";

//	 ASSIGNED ADMINS
	public String GET_ADMINS_NULL_POINTER_EXCEPTION = "No Assigned Admins Found";

}

