package com.example.demo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

//import com.example.demo.Controller.AdminController;
//import com.example.demo.Service.AdminService;
import com.example.demo.constantss.LoggerMessage;
import com.example.demo.constantss.URLConstants;
import com.example.demo.exceptions.BadRequestException;
import com.example.demo.model.Admins;

import com.example.demo.repository.AdminsRepo;
//import com.example.demo.repository.UserRepository;

@RestController
@CrossOrigin(origins = { URLConstants.CROSS_ORIGIN_URL })
public class AdminController {
	private static final Logger LOGGER = LoggerFactory.getLogger(AdminController.class);
	
	@Autowired
	private AdminsRepo adminrepo;

	@GetMapping(value = { URLConstants.ASSIGNED_ADMINS }, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Admins> getAllAdmins() {
		LOGGER.info("Entering the Admins Data controller....");
	
		try {
			

			LOGGER.info(LoggerMessage.SUCCESS_MESSAGE);
			LOGGER.info(LoggerMessage.SUCCESSFULLY_FETCHED_ADMINS_MSG);

			return  adminrepo.getAdmins();
		} catch (BadRequestException e) {
			throw new BadRequestException(LoggerMessage.BAD_REQUEST, e);
		} catch (NullPointerException e) {
			throw new NullPointerException(LoggerMessage.GET_ADMINS_NULL_POINTER_EXCEPTION);
		}

	}
	

//	@GetMapping("/getAllAdmins")
//	public List<Admins> getAllAdmins() {
//		return  adminrepo.getAdmins();
//	}

}
