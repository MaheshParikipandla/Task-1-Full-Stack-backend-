import react, { useEffect, useState } from 'react';
import axios from "axios";
const Effect = () => {
    const [data, setData] = useState("");

    useEffect = () => {
        axios.get("http://localhost:8080/userroles").then((response) => {
            setData(response.data[0].role);
            console.log("api is called")
        })
    }
    return (
        <div>
            <h1>Hello {data}</h1>
        </div>
    );
}
export default Effect;