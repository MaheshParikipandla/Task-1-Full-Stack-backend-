import React from "react";
import { useState } from "react";
import { FaArrowLeft, FaTimes, FaUnderline } from "react-icons/fa";
import "./SlideDrawer.css";
import Admins from "../AssignedAdmins/Admins";
import Apps from "../ApplicationAccess/Apps";
import "./SlideDrawer.css";

const SlideDrawer = (props) => {
  const [clicked, setclicked] = useState(true);
  const [role, setRole] = useState([]);
  //  useEffect(() => {
  //   console.log(props.data);
  //   axios
  //     .get(`http://localhost:8080/userroles/${props.data}`)
  //     .then((res) => setRole(res.data));
  // }, [props]);

  return (
    <div className="window">
      <p style={{ paddingLeft: "400px" }}>
        {" "}
        <a href="/">
          <FaArrowLeft> </FaArrowLeft>{" "}
        </a>
        &nbsp; &nbsp;
        <a href="/">
          <FaTimes></FaTimes>
        </a>
      </p>

      {/*............ selected role &data  is fetched from rolegroups ........ */}

      <h6 className="data">{props.data}</h6>
      <div className="heading">
        <div className="row">
          <div className="col" style={{ paddingLeft: "20px" }}>
            <tr onClick={() => setclicked(true)}>
              <p>Application Access</p>
            </tr>
          </div>
          <div className="col" style={{ paddingRight: "100px" }}>
            <tr onClick={() => setclicked(false)}>
              <h6>Assigned Admins</h6>
            </tr>
          </div>
        </div>
      </div>

      <div>{clicked ? <Apps></Apps> : <Admins></Admins>}</div>
    </div>
  );
};
export default SlideDrawer;
