import React, { Component } from "react";
import "./administrator.css";
import a from "../assets/images/a.png";
import "./SideBar.css";
import { FaUser } from "react-icons/fa";

class Administrator extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <div class="rows">
        <div class="topnav">
          <a class="navbar-brand" href="" style={{ paddingLeft: "10px" }}>
            <img src={a} width="50" height="40" />
          </a>
          <div class="admin">
            <a>
              <p class="pt-3">
                <h6>ADMINISTRATION</h6>
              </p>
            </a>
          </div>
          <a>
            <i id="icon" class="fa fa-user ms-auto" aria-hidden="true"></i>
          </a>
          <div class="usericon">
            <p>
              <FaUser style={{ fontWeight: "bolder" }}></FaUser>
            </p>
          </div>
        </div>
      </div>
    );
  }
}
export default Administrator;
