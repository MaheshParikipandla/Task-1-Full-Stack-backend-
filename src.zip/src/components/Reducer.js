import React, { useReducer } from "react";

const Reducer = (state, action) => {
  switch (action.type) {
    case "INCREMENT":
      return { count: state.count +1 };
    case "DECREMENT":
      return { count: state.count - 1 };
    default:
      return state;
  }
};

const ReducerAction = () => {
  const [state, dispatch] = useReducer(Reducer, { count: 0 });
   

  return (
    <div>
      {state.count}
      <br></br>
      <button
        onClick={() => {
          dispatch({ type: "INCREMENT" });
         
        }}
      >
      
        increment
      </button>
       <button
        onClick={() => {
          
          dispatch({ type: "DECREMENT" });
        }}
      >
      
        decrement
      </button>
      <br></br>
      {/* {state.text && <p>Mahesh</p>} */}
    </div>
  );
};
export default ReducerAction;
