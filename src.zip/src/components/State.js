import React, { useState } from "react";
const State = () => {
    const [counter, setCounter] = useState(0);
    console.log('i rendered');
    return (
        <div>          
            {/* onclick */}
            {counter}<br></br>
            <button onClick={() => setCounter(counter + 1)}>Increment</button><br></br> 
            {/* onchange */}
            <button onClick={()=>setCounter(counter-1)}>Decrement</button>
        </div>
    );    
}
export default State;