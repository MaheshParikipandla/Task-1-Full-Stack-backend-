
import React from 'react';
import ReactDOM from 'react-dom';


import Administrator from '../Administrator';
import { render } from '@testing-library/react'


it("renders without crashing", () => {
    const div = document.createElement("div");
    ReactDOM.render(<Administrator />, div)
})
it("renders properly at top of the page", () => {
    const { getByTestId } = render(<Administrator />)
    expect(getByTestId('topnav')).toBeVisible(<Administrator />)
})
it("renders properly heading", () => {
    const { getByTestId } = render(< Administrator topnav="ADMINISTRATION" />)
    expect(getByTestId('topnav')).toHaveTextContent("ADMINISTRATION")
})

it("checking width AND height of an admin image ", () => {
 const { getByTestId } = render(<Administrator />)
expect(getByTestId('adminimage')).toHaveAttribute('width', '50');
expect(getByTestId('adminimage')).toHaveAttribute('height', '40');
});

it("check css properties of columns", () => {
  const { getByTestId } = render(<Administrator />);
  expect(getByTestId("adminleft")).toHaveStyle(`
  font-size: 15px;
`);  
});