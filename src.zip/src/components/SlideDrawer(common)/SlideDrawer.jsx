import React from "react";
import { useState } from "react";
import { FaArrowLeft, FaTimes, FaUnderline } from "react-icons/fa";
import "./SlideDrawer.css";
import Admins from "../AssignedAdmins/Admins";
import Apps from "../ApplicationAccess/Apps";
import "./SlideDrawer.css";
const SlideDrawer = (props) => {
  const [clicked, setclicked] = useState(true);

  return (
    <div class="window">
      <p style={{ paddingLeft: "400px" }}>
        {" "}
        <a href="/">
          <FaArrowLeft> </FaArrowLeft>{" "}
        </a>
        &nbsp; &nbsp;{" "}
        <a href="/">
          <FaTimes></FaTimes>
        </a>
      </p>
      {/*............ selected role &data  is fetched from rolegroups ........ */}
      <h6 class="data">{props.data}</h6>
      <div className="heading">
        <div class="row">
          <div class="col" style={{ paddingLeft: "20px" }}>
            <tr onClick={() => setclicked(true)}>
              <p>Application Access</p>
            </tr>
          </div>
          <div class="col" style={{ paddingRight: "100px" }}>
            <tr onClick={() => setclicked(false)}>
              <h6>Assigned Admins</h6>
            </tr>
          </div>
        </div>
      </div>

      <div>{clicked ? <Apps></Apps> : <Admins></Admins>}</div>
    </div>
  );
};
export default SlideDrawer;
