import React from "react";
import ReactDOM from "react-dom";
import renderer from "react-test-renderer";
import { toHaveStyle } from "@testing-library/jest-dom";
import { render, screen, fireEvent } from "@testing-library/react";
import "jest-styled-components";
import RoleGroups from "../RoleGroups";
import "@testing-library/jest-dom/extend-expect";

it("renders without crashing", () => {
  const div = document.createElement("div");
  ReactDOM.render(<RoleGroups />, div);
});

test("render user role  data element", () => {
  render(<RoleGroups />);
  expect(screen.getByText("User roles")).toBeInTheDocument();
});
test("render Description data element", () => {
  render(<RoleGroups />);
  expect(screen.getByText("Description")).toBeInTheDocument();
});
test("render Roles element", () => {
  render(<RoleGroups />);

  expect(screen.getByText("Roles")).toBeInTheDocument();
});

<button data-testid="userroles" style="background-color: ededed"></button>;
it("render table", () => {
  const { getByTestId } = render(<RoleGroups />);

  const input = getByTestId("table");

  expect(input).toBeTruthy();
});
it("render thead", () => {
  const { getByTestId } = render(<RoleGroups />);

  const input = getByTestId("thead");

  expect(input).toBeTruthy();
});
it("render tbody", () => {
  const { getByTestId } = render(<RoleGroups />);

  const input = getByTestId("tbody");

  expect(input).toBeTruthy();
});

it("initially description text content", () => {
  const { getByTestId } = render(<RoleGroups />);

  expect(getByTestId("description")).toHaveTextContent(/^Description$/); // to match the whole content
  expect(getByTestId("description")).toHaveTextContent(/description$/i); // to use case-insensitive match
  expect(getByTestId("description")).not.toHaveTextContent("h");
});

it("check css properties of description", () => {
  const { getByTestId } = render(<RoleGroups />);
  expect(getByTestId("description")).toHaveStyle(`
  font-size: 13px;
   font-weight: bold;
`);
});

