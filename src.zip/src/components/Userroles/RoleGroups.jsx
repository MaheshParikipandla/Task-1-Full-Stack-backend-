import React, { useEffect, useState } from "react";
import axios from "axios";
import "./RoleGroups.css";
import { VscAccount, VscCircleSlash } from "react-icons/vsc";
import SlideDrawer from "../SlideDrawer(common)/SlideDrawer";
import { FaCheckCircle, FaGreaterThan, FaHamburger } from "react-icons/fa";
const RoleGroups = () => {
  const [roledata, setRoledata] = useState([]);
  const [role, setRole] = useState(0);
  const [isclicked, setisclicked] = useState(false);
  const [searchterm, setSearchTerm] = useState("");
  useEffect(() => {
    axios
      .get("http://localhost:8080/userroles")
      .then((res) => setRoledata(res.data));
  }, []);

  return (
    <div>
      <div class="top">
        <div class="loc">
          <p class="innerloc">
            Home &nbsp;<FaGreaterThan></FaGreaterThan> &nbsp; Roles
          </p>

          <p class="roles"> Roles </p>

          <p class="adddel">
            <VscAccount style={{ color: "blue" }}></VscAccount>
            <a> </a>Add Role <a style={{ color: "rgb(240, 236, 236)" }}>j</a>
            <VscCircleSlash style={{ color: "blue" }}></VscCircleSlash> Delete
            Role
          </p>
          <div class="search">
            <i id="rightSide" class="fa fa-search"></i> &nbsp;
            <input
              type="search"
              id="form1"
              class="no-outline"
              placeholder="Search roles"
              aria-label="Search"
              onChange={(event) => {
                setSearchTerm(event.target.value);
              }}
            />
            <i class="fa fa-bars" aria-hidden="true"></i>
          </div>
        </div>

        <div class="row">
          <div class="column">
            <table>
              <thead>
                <tr>
                  <th></th>
                  <th class="userroles">User roles</th>

                  <th> </th>
                  <th class="description">Description</th>
                </tr>
              </thead>
              <tbody>
                {roledata
                  .filter((ob) => {
                    if (searchterm == "") {
                      return ob;
                    } else if (
                      ob.role.toLowerCase().includes(searchterm.toLowerCase())
                    ) {
                      return ob;
                    }
                  })
                  .map((ob) => (
                    <tr
                      onClick={() => {
                        setisclicked(true);
                        setRole(ob.role);
                      }}
                      style={
                        isclicked && ob.role === role
                          ? { backgroundColor: "#ededed" }
                          : null
                      }
                    >
                      <td class="aligndata">
                        {" "}
                        {isclicked && ob.role === role ? (
                          <FaCheckCircle
                            style={{ color: "blue" }}
                          ></FaCheckCircle>
                        ) : null}
                      </td>
                      <td class="roledata">
                        {/*............ all roles are fetched here...... */}

                        {ob.role}
                      </td>
                      <td class="dots">:</td>
                      <td class="descdata">
                        {/*............ all role description is fetched here...... */}
                        {ob.description}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      {isclicked ? (
        <div className="activeuserdetails">
          <SlideDrawer data={role}></SlideDrawer>
        </div>
      ) : null}
    </div>
  );
};
export default RoleGroups;
