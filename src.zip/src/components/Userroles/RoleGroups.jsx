import React, { useEffect, useState } from "react";
import { logger } from "react-native-logs";

// import config from "../../config";
import "./RoleGroups.css";
import { VscAccount, VscCircleSlash } from "react-icons/vsc";

import { toast } from "react-toastify";
import SlideDrawer from "../SlideDrawer/SlideDrawer";
import { FaCheckCircle, FaGreaterThan } from "react-icons/fa";
import RoleGroupsService from "./RoleGroupsService";

const RoleGroups = () => {
  const [roledata, setRoledata] = useState([]);
  const [role, setRole] = useState(0);
  const [isclicked, setisclicked] = useState(false);
  const [searchterm, setSearchTerm] = useState("");

  var log = logger.createLogger();

  useEffect(() => {
    try {
      RoleGroupsService.retrieveAllRoles()
      .then((res) => {
        setRoledata(res.data);
        toast.success("User roles are fetched successfully");
        log.info("User roles Data fetched successfully");
      });
    } catch (error) {
      toast.error("unable to fetch data from server");
      log.error("unable to fetch data from server");
    }
  }, []);

  return (
    <div data-testid="userroles">
      <div className="top">
        <div className="loc">
          <p className="innerloc" data-testid="innerloc" style={{ paddingTop: "20px", fontSize: "12px", fontWeight:"lighter"}}>
            Home &nbsp;<FaGreaterThan></FaGreaterThan> &nbsp; Roles
          </p>
          
          <p className="roles" data-testid="roles" style={{ fontSize: "20px", fontWeight:"bold"}}> Roles </p>

          <p className="adddel" data-testid="adddel" style={{ fontSize: "13px",fontWeight: "lighter"}}>
            <VscAccount data-testid="VsAccount" style={{ color: "blue" }}></VscAccount>
            <a> </a>Add Role <a  data-testid="AddRole" style={{ color: "rgb(240, 236, 236)" }}>j</a>
            <VscCircleSlash data-testid="circleslash" style={{ color: "blue" }}></VscCircleSlash> Delete
            Role
          </p>
          <div className="search" data-testid="search">
            <i id="rightSide" className="fa fa-search"></i> &nbsp;
            <input
              type="search"
              id="form1"
              className="no-outline"
              placeholder="Search roles"
              aria-label="Search"
              onChange={(event) => {
                setSearchTerm(event.target.value);
              }}
            />
            <i className="fa fa-bars" aria-hidden="true"></i>
          </div>
        </div>

        <div className="row">
          <div className="column">
            <table data-testid="table">
              <thead data-testid="thead">
                <tr>
                  <th></th>
                  <th className="userroles" data-testid="userrole" style={{fontSize:"13px",fontWeight: "lighter",paddingLeft: "50px"}}>
                    User roles
                  </th>

                  <th> </th>
                  <th className="description" data-testid="description" style={{ fontSize: "13px"}}>
                    Description 
                  </th>
                </tr>
              </thead>
              <tbody data-testid="tbody">
                {roledata
                  .filter((ob) => {
                    if (searchterm == "") {
                      return ob;
                    } else if (
                      ob.role.toLowerCase().includes(searchterm.toLowerCase())
                    ) {
                      return ob;
                    }
                  })
                  .map((ob) => (
                    <tr
                      onClick={() => {
                        setisclicked(true);
                        setRole(ob.role);
                      }}
                       data-testid="buttoncolor"
                      style={
                        isclicked && ob.role === role
                          ? { backgroundColor: "#efefef" }
                          : null
                      }
                    >
                      <td className="aligndata" data-testid="aligndata" style={{ width:"3%"}}>
                        {" "}
                        {isclicked && ob.role === role ? (
                          <FaCheckCircle
                            data-testid="facircle"
                            style={{ color: "blue" }}
                          ></FaCheckCircle>
                        ) : null}
                      </td>
                      <td className="roledata" data-testid="roledata" style={{paddingLeft:"30px"}} >
                        {/*............ all roles are fetched here...... */}

                       {ob.role}
                      </td>
                      <td className="dots">:</td>
                      <td className="descdata" data-testid="descriptiondata" style={{fontSize:"13px"}}>
                        {/*............ all role description is fetched here...... */}
                        {ob.description}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      {isclicked ? (
        <div className="activeuserdetails">
          <SlideDrawer data={role}></SlideDrawer>
        </div>
      ) : null}
    </div>
  );
};
export default RoleGroups;
