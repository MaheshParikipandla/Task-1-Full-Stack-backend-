import axios from "axios";


import AppSettings from "../../app.settings";
class RoleGroupsService {
  
  retrieveAllRoles() {
    try {
      console.log("executed User role service");
  
      return axios.get(`${AppSettings.service_host_url}/userroles`);
    } catch (error) {
        console.log("Unable to find service url");
  
    }
    
  }
    
}

export default new RoleGroupsService();
