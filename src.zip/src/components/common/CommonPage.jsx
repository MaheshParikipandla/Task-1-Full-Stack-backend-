import React, { Component } from "react";

import SideBar from "../SideBar/SideBar";
import RoleGroups from "../Userroles/RoleGroups";
class CommonPage extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <div>
        <div className="containers">
          <div className="boxes1">
            <SideBar></SideBar>
          </div>

          <div className="boxes2">
            <RoleGroups></RoleGroups>
          </div>
        </div>
      </div>
    );
  }
}
export default CommonPage;
