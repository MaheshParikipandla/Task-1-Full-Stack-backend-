import React, { Component } from "react";

import SideBar from "../SideBar(common)/SideBar";
import RoleGroups from "../Userroles/RoleGroups";
class CommonPage extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return (
      <div>
        <div class="containers">
          <div class="boxes1">
       
            <SideBar></SideBar>
          </div>

          <div class="boxes2">
         
            <RoleGroups></RoleGroups>
          </div>
        </div>
      </div>
    );
  }
}
export default CommonPage;
