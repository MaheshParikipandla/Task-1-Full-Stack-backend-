import axios from 'axios'

import AppSettings from '../../app.settings';
class AppService {

    retrieveAllApps() {
        try {
            console.log('executed Application access service')
            return axios.get(`${AppSettings.service_host_url}/applicationaccess`);
        } catch (error) {
        console.log("Unable to find service url");
  
    }
    }

   
}

export default new AppService()