import React, { useEffect, useState } from "react";
import "./Apps.css";
import { logger } from "react-native-logs";
import { FaArrowLeft, FaCheck, FaTimes, FaXbox } from "react-icons/fa";
import AppService from "./AppService";
import { toast } from "react-toastify";
const Apps = (props) => {
  const [appdata, setAppdata] = useState([]);
  const [isclicked1, setisclicked1] = useState(false);
var log = logger.createLogger();
  useEffect(() => {
    try {
    
    AppService.retrieveAllApps().then((res) => setAppdata(res.data));
      toast.success("Applications are fetched successfully");
      log.info("Applications data fetched successfully")
      
    } catch (error) {
      log.error('unable to fetch data from server');
    }
    
  }, [props]);

  return (
    <div data-testid="apps">
      <div className="containers">
        {/*............ selected role &data  is fetched from rolegroups ........ */}

        <p className="propsdata">{props.data}</p>

        <div className="col-pad" data-testid="col-pad" style={{paddingLeft: "20px"}}>
          <table data-testid="table">
            <thead data-testid="thead">
              <tr>
                <th> </th>
              </tr>
            </thead>
            <tbody data-testid="tbody">
              {appdata.length
                ? appdata.map((stds) => (
                    <tr key={stds.id}>
                      <td className="appsdata" data-testid="appsdata" style={{ fontSize: "14px"}}>
                        <FaCheck className="checkicon"></FaCheck> &nbsp; &nbsp;
                        {/*............ all apps are fetched here...... */}
                        {stds.apps}
                      </td>
                    </tr>
                  ))
                : null}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
export default Apps;
