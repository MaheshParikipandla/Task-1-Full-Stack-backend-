import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

import "./Apps.css";

import { FaArrowLeft, FaCheck, FaTimes, FaXbox } from "react-icons/fa";

const Apps = (props) => {
  const [appdata, setAppdata] = useState([]);
  const [isclicked1, setisclicked1] = useState(false);

  // const [role,setRole]=useState(0);
  // const [isclicked, setisclicked] = useState(false);
  useEffect(() => {
    console.log(props.data);
    axios
      .get("http://localhost:8080/applicationaccess")
      .then((res) => setAppdata(res.data));
  }, [props]);

  return (
    <div>
      <div class="containers">
        {/*............ selected role &data  is fetched from rolegroups ........ */}
        <p class="propsdata">{props.data}</p>

        <div class="col-pad">
          <table>
            <thead>
              <tr>
                <th> </th>
              </tr>
            </thead>
            <tbody>
              {appdata.length
                ? appdata.map((stds) => (
                    <tr key={stds.id}>
                      <td class="appsdata">
                        <FaCheck class="checkicon"></FaCheck> &nbsp; &nbsp;
                        {/*............ all apps are fetched here...... */}
                        {stds.apps}
                      </td>
                    </tr>
                  ))
                : null}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
export default Apps;
