
import React from 'react';
import ReactDOM from 'react-dom';
import ApplicationAccess from '../Apps'


import { render,screen} from '@testing-library/react'


it("renders without crashing", () => {
    const div = document.createElement("div");
    ReactDOM.render(<ApplicationAccess />, div)
})
it("renders properly at right side of the page", () => {
    const { getByTestId } = render(<ApplicationAccess />)
    expect(getByTestId('apps')).toBeVisible(<ApplicationAccess />)
})
it("render table", () =>{

    const {getByTestId} = render(<ApplicationAccess/>);

    const input = getByTestId("table");

    expect(input).toBeTruthy();

})
it("render thead", () =>{

    const {getByTestId} = render(<ApplicationAccess/>);

    const input = getByTestId("thead");

    expect(input).toBeTruthy();

})
it("render tbody", () =>{

    const {getByTestId} = render(<ApplicationAccess/>);

    const input = getByTestId("tbody");

    expect(input).toBeTruthy();

})
it("check css properties of columns", () => {
  const { getByTestId } = render(<ApplicationAccess />);
  expect(getByTestId("col-pad")).toHaveStyle(`
  paddingLeft: 20px;
`);
   
});





