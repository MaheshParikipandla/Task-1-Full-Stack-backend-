import React from "react";
import { Link } from "react-router-dom";
// import logo from "../assets/images/logo.png";
// import s2 from "../assets/images/s2.png";
// import ss from "../assets/images/ss.png";
// import side from "../assets/images/side.png";
import "./SideBar.css";

const SideBar = () => {
  return (
    <div>
      <nav id="sidebar">
        <ul class="list-unstyled components">
          <li>
            <a href="/">
              <i class="fa fa-home ml-3 mr-2 mt-4" aria-hidden="true"></i>Home
            </a>
          </li>
          <li class="active">
            <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">
              <i class="fas fa-user-friends ml-3 mr-2"></i>
              Users
              <i id="drop" class="fas fa-angle-down"></i>
            </a>
            <ul class="collapse list-unstyled ml-4" id="homeSubmenu">
              <li>
                <Link to={"/activeuserlist"}>Active users</Link>
              </li>
              <li>
                <a href="/">Contact</a>
              </li>
              <li>
                <a href="/">Deleted Users</a>
              </li>
              <li>
                <a href="/">Users settings</a>
              </li>
            </ul>
          </li>
          <li>
            <a
              href="#GroupsSubmenu"
              data-toggle="collapse"
              aria-expanded="false"
            >
              <i class="fas fa-users ml-3 mr-2"></i>
              Groups
              <i id="drop" class="fas fa-angle-down"></i>
            </a>
          </li>
          <li>
            <a href="/">
              {/* <img src={side} width="4" height="20" /> */}
              &nbsp;
              <i class="fas fa-user-plus ml-2 mr-2"></i>Roles
            </a>
          </li>
          <li class="active">
            <a
              href="#settingsSubmenu"
              data-toggle="collapse"
              aria-expanded="false"
            >
              <i class="fa fa-cog ml-3 mr-2" aria-hidden="true"></i>
              Settings
              <i id="drop" class="fas fa-angle-down"></i>
            </a>
            <ul class="collapse list-unstyled ml-3 mr-2" id="settingsSubmenu">
              <li>
                <a href="/">Integrated apps</a>
              </li>
            </ul>
          </li>
        </ul>
        <ul class="list-unstyled ml-3 mr-2">
          <li>
            <a href="#Home">
              {/* <img
                src={ss}
                width="15"
                height="15"
                // class="fix"

                alt=""
              />{" "} */}
              &nbsp;Apps admin centers
            </a>
          </li>

          <li>
            <a href="#Home">
              {/* <img
                src={s2}
                width="20"
                height="20"
                // class="fix"

                alt=""
              />{" "} */}
              &nbsp;Impersonate user
            </a>
          </li>
        </ul>

        {/* <img src={logo} width="210" height="80" class="fix" alt="" /> */}
      </nav>
    </div>
  );
};
export default SideBar;
