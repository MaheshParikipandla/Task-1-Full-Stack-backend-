import React from "react";
import { Link } from "react-router-dom";
import logo from "../../assets/images/logo.png";
import s2 from "../../assets/images/s2.png";
import ss from "../../assets/images/ss.png";
import side from "../../assets/images/side.png";
import "./SideBar.css";

const SideBar = () => {
  return (   
    <div data-testid="sidebar"> 
         <nav id="sidebar">
        <ul className="list-unstyled components">
          <li>
            <a href="/">
              <i className="fa fa-home ml-3 mr-2 mt-4" aria-hidden="true"></i>Home
            </a>
          </li>
          <li className="active">
            <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false">
              <i className="fas fa-user-friends ml-3 mr-2"></i>
              Users
              <i id="drop" className="fas fa-angle-down" data-testid="drop"></i>
            </a>
            <ul className="collapse list-unstyled ml-4" id="homeSubmenu" data-testid="dashboard">
              <li>
                {/* <Link to={"/activeuserlist"}> */}
                  Active users
                {/* </Link> */}
              </li>
              <li>
                <a href="/">Contact</a>
              </li>
              <li>
                <a href="/">Deleted Users</a>
              </li>
              <li>
                <a href="/">Users settings</a>
              </li>
            </ul>
          </li>
          <li>
            <a
              href="#GroupsSubmenu"
              data-toggle="collapse"
              aria-expanded="false"
            >
              <i className="fas fa-users ml-3 mr-2"></i>
              Groups
              <i id="drop" className="fas fa-angle-down" ></i>
            </a>
          </li>
          <li>
            <a href="/">
              <img src={side} width="4" height="20" />
              &nbsp;
              <i className="fas fa-user-plus ml-2 mr-2"></i>Roles
            </a>
          </li>
          <li className="active">
            <a
              href="#settingsSubmenu"
              data-toggle="collapse"
              aria-expanded="false"
            >
              <i className="fa fa-cog ml-3 mr-2" aria-hidden="true"></i>
              Settings
              <i id="drop" className="fas fa-angle-down" ></i>
            </a>
            <ul className="collapse list-unstyled ml-3 mr-2" id="settingsSubmenu">
              <li>
                <a href="/">Integrated apps</a>
              </li>
            </ul>
          </li>
        </ul>
        <ul className="list-unstyled ml-3 mr-2">
          <li >
            <a href="#Home">
              <img data-testid="ssimage"
                src={ss}
                width="15"
                height="15"
                

                alt=""
              />{" "}
              &nbsp;Apps admin centers
            </a>
          </li>

          <li>
            <a href="#Home">
              <img data-testid="s2image"
                src={s2}
                width="20"
                height="20"
                // class="fix"

                alt=""
              />{" "}
              &nbsp;Impersonate user
            </a>
          </li>
        </ul>

        <img src={logo} data-testid="logoimage" width="210" height="80" className="fix"  alt="" />
        </nav>
         </div>


        
     
     
     
    
  );
};
export default SideBar;
