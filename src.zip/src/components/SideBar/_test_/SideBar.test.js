
import React from 'react';
import ReactDOM from 'react-dom';


import "@testing-library/jest-dom/extend-expect";
import { render,screen } from '@testing-library/react'
import SideBar from '../SideBar';


it("renders without crashing", () => {
    const div = document.createElement("div");
    ReactDOM.render(<SideBar />, div)
})
it("renders properly at left corner of the page", () => {
    const { getByTestId } = render(<SideBar />)
    expect(getByTestId('sidebar')).toBeVisible(<SideBar />)
})
test('render Home element', () => {
  render(<SideBar />);
  expect(screen.getByText('Home')).toBeInTheDocument();
});
test('render Users element', () => {
  render(<SideBar />);
  expect(screen.getByText('Users')).toBeInTheDocument();
});
test('render Roles element', () => {
  render(<SideBar />);
  expect(screen.getByText('Roles')).toBeInTheDocument();
});
test('render Groups element', () => {
  render(<SideBar />);
  expect(screen.getByText('Groups')).toBeInTheDocument();
});

test('render Apps admin centers element', () => {
  render(<SideBar />);
  expect(screen.getByText('Apps admin centers')).toBeInTheDocument();
});

test('render  centers element', () => {
  render(<SideBar />);
  expect(screen.getByText('Impersonate user')).toBeInTheDocument();
});

it("initially displays as white with a light teal hover", () => {
 const { getByTestId } = render(<SideBar />)
expect(getByTestId('sidebar')).toHaveStyle({display: 'block'})
});


it("checking width AND height of an ss image ", () => {
 const { getByTestId } = render(<SideBar />)
expect(getByTestId('ssimage')).toHaveAttribute('width', '15');
expect(getByTestId('ssimage')).toHaveAttribute('height', '15');
});

it("checking width AND height of an s2 image ", () => {
 const { getByTestId } = render(<SideBar />)
expect(getByTestId('s2image')).toHaveAttribute('width', '20');
expect(getByTestId('s2image')).toHaveAttribute('height', '20');
});

it("checking width AND height of an logo image ", () => {
 const { getByTestId } = render(<SideBar />)
expect(getByTestId('logoimage')).toHaveAttribute('width', '210');
expect(getByTestId('logoimage')).toHaveAttribute('height', '80');
});


