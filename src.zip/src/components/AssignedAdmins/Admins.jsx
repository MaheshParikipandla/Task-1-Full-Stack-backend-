import React, { useState, useEffect } from "react";
import axios from "axios";

import "./Admins.css";

import { FaArrowLeft, FaCheck, FaTimes, FaXbox } from "react-icons/fa";
import { VscAdd } from "react-icons/vsc";
import { Link } from "react-router-dom";

const Admins = (props) => {
  const [addata, setAdata] = useState([]);
  const [isclicked1, setisclicked1] = useState(false);
  const [isclicked, setisclicked] = useState(false);

  useEffect(() => {
    axios
      .get("http://localhost:8080/assignedadmins")
      .then((res) => setAdata(res.data));
  }, [props]);

  return (
    <div>
      <p class="propsadmindata"> {props.data} </p>
      <div class="col-padr">
        <p>
          {" "}
          <VscAdd></VscAdd>
          <a style={{ fontSize: "10px" }}> &nbsp; </a>
          Add admin
        </p>
      </div>

      <table>
        <thead>
          <tr style={{ paddingBottom: "20px" }}>
            <th class="adminhead">Admin </th>
            <th class="signinhead">Last sign-in</th>
          </tr>
        </thead>
        <tbody>
          {addata.length
            ? addata.map((std) => (
                <tr key={std.id}>
                  <td class="admindata">
                    {/*............ selected rolesdata  admins are fetched here ........ */}
                    {std.admin}
                  </td>
                  {/*............ selected rolesdata  admins & their last signin is fetched here ........ */}
                  <td class="signindata">{std.signin}</td>
                </tr>
              ))
            : null}
        </tbody>
      </table>
    </div>
  );
};
export default Admins;
