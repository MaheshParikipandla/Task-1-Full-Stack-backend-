import React, { useState, useEffect } from "react";
import "./Admins.css";
import { toast } from "react-toastify";
import { VscAdd } from "react-icons/vsc";
import { logger } from "react-native-logs";
import AdminService from "./AdminService";

const Admins = (props) => {
  const [addata, setAdata] = useState([]);
  var log = logger.createLogger();
  useEffect(() => {
    try {
      AdminService.retrieveAllAdmins().then((res) => setAdata(res.data));
      toast.success(`Assigned Admins are fetched successfully `);
      log.info("User roles Data fetched successfully")
    }
  catch (error)
    {
       toast.error('unable to fetch data from server');
     log.error('unable to fetch data from server');
  }
  }, [props]);

  return (
    <div data-testid="admins">
      <p className="propsadmindata" > {props.data} </p>
      <div className="col-padr" data-testid="col-padrp" style={{ color: "blue" }}>
        <p>
          <VscAdd></VscAdd>
          <a  style={{ fontSize: "10px" }}> &nbsp; </a>
          Add admin
        </p>
      </div>

      <table data-testid="table">
        <thead data-testid="thead">
          <tr style={{ paddingBottom: "20px" }}>
            <th className="adminhead">Admin </th>
            <th className="signinhead">Last sign-in</th>
          </tr>
        </thead>
        <tbody data-testid="tbody">
          {addata.length
            ? addata.map((std) => (
                <tr key={std.id}>
                  <td className="admindata">
                    {/*............ selected rolesdata  admins are fetched here ........ */}

                    {std.admin}
                  </td>

                  {/*............ selected rolesdata  admins & their last signin is fetched here ........ */}

                  <td className="signindata">{std.signin}</td>
                </tr>
              ))
            : null}
        </tbody>
      </table>
    </div>
  );
};
export default Admins;
