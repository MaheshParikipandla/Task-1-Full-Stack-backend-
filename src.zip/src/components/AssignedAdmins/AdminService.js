import axios from "axios";
import AppSettings from "../../app.settings";
class AdminService {
  retrieveAllAdmins() {
    try {
      console.log("executed Admin service");
      return axios.get(`${AppSettings.service_host_url}/assignedadmins`);
    } catch (error) {
        console.log("Unable to find service url");
  
    }
  }
}

export default new AdminService();
