
import React from 'react';
import ReactDOM from 'react-dom';
import AssignedAdmins from '../Admins'


import { render, screen } from '@testing-library/react';


it("renders without crashing", () => {
    const div = document.createElement("div");
    ReactDOM.render(<AssignedAdmins />, div)
})
it("renders properly at right side of the page", () => {
    const { getByTestId } = render(<AssignedAdmins />)
    expect(getByTestId('admins')).toBeVisible(<AssignedAdmins />)
})
test('render Admin element', () => {
  render(<AssignedAdmins />);
  expect(screen.getByText('Admin')).toBeInTheDocument();
});
it("render table", () =>{

    const {getByTestId} = render(<AssignedAdmins/>);

    const input = getByTestId("table");

    expect(input).toBeTruthy();

})
it("render thead", () =>{

    const {getByTestId} = render(<AssignedAdmins/>);

    const input = getByTestId("thead");

    expect(input).toBeTruthy();

})
it("render tbody", () =>{

    const {getByTestId} = render(<AssignedAdmins/>);

    const input = getByTestId("tbody");

    expect(input).toBeTruthy();

})

it("check css properties of Admins", () => {
  const { getByTestId } = render(<AssignedAdmins />);
  expect(getByTestId("col-padrp")).toHaveStyle(`
  color:blue;
`);
   
});


