
import React from 'react';
import ReactDOM from 'react-dom';
import AssignedAdmins from '../Admins'


import { render, screen } from '@testing-library/react';


it("renders without crashing", () => {
    const div = document.createElement("div");
    ReactDOM.render(<AssignedAdmins />, div)
})
it("renders properly at right side of the page", () => {
    const { getByTestId } = render(<AssignedAdmins />)
    expect(getByTestId('admins')).toBeVisible(<AssignedAdmins />)
})
test('render Admin element', () => {
  render(<AssignedAdmins />);
  expect(screen.getByText('Admin')).toBeInTheDocument();
});
it("render table", () =>{

    const {getByTestId} = render(<AssignedAdmins/>);

    const input = getByTestId("table");

    expect(input).toBeTruthy();

})
it("render thead", () =>{

    const {getByTestId} = render(<AssignedAdmins/>);

    const input = getByTestId("thead");

    expect(input).toBeTruthy();

})
it("render tbody", () =>{

    const {getByTestId} = render(<AssignedAdmins/>);

    const input = getByTestId("tbody");

    expect(input).toBeTruthy();

})

it("check css properties of Admins", () => {
  const { getByTestId } = render(<AssignedAdmins />);
  expect(getByTestId("col-padrp")).toHaveStyle(`
  color:blue;
`);  
});

it("check css properties of Admins", () => {
  const { getByTestId } = render(<AssignedAdmins />);
  expect(getByTestId("AddAdmin")).toHaveStyle(`
  font-size:10px;
  padding-left: 30px;
  padding-top: 17px;
`);  
});

it("check css properties of Admins", () => {
  const { getByTestId } = render(<AssignedAdmins />);
  expect(getByTestId("table")).toHaveStyle(`
  width:100%;
`);  
});
it("check css properties of Admins", () => {
  const { getByTestId } = render(<AssignedAdmins />);
  expect(getByTestId("admin-signin")).toHaveStyle(`
  padding-bottom:20px;
`);  
});

it("check css properties of Admins", () => {
  const { getByTestId } = render(<AssignedAdmins />);
  expect(getByTestId("adminhead")).toHaveStyle(`
   font-weight: lighter;
  padding-left: 60px;
  font-size: 13px;
`);  
});
it("check css properties of Admins", () => {
  const { getByTestId } = render(<AssignedAdmins />);
  expect(getByTestId("signinhead")).toHaveStyle(`
   font-weight: lighter;
  padding-left: 12px;
  font-size: 13px;
`);  
});

// it("check css properties of Admins", () => {
//   const { getByTestId } = render(<AssignedAdmins />);
//   expect(getByTestId("admindata")).toHaveStyle(`
//     font-family: sans-serif;
//   font-weight: bold;
//   font-size: 13px;
//   padding-left: 55px;
// `);  
// });
// it("check css properties of Admins", () => {
//   const { getByTestId } = render(<AssignedAdmins />);
//   expect(getByTestId("signindata")).toHaveStyle(`
//   font-size: 13px;
// `);  
// });