import react, { useEffect, useRef, useState } from 'react';

const Ref=()=> {
  const countRef = useRef(0);
  const handle = () => {
    countRef.current++;
    console.log(`Clicked ${countRef.current} times`);
  };
    console.log("I rendered for ref!");
    
    // state
    // const [count, setCount] = useState(0);
    // const handleOne = () => {
    //  const Updatedcount=count+1;
    //     console.log(`Clicked ${Updatedcount} times`);
    //     setCount(Updatedcount);
    // };
    // console.log("I rendered! for state");
    return (
        <div>
            <h1>{countRef.current}</h1>
            <button onClick={handle}>Click me for ref</button><br></br>
          
            {/* <button onClick={handleOne}>Click me for state</button> */}

      </div>
  ) 
}
export default Ref;