import logo from "./logo.svg";
import "./App.css";
import React from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import Administrator from "./components/administrator";

import CommonPage from "./components/common/CommonPage";


function App() {
  return (
    <div className="App">
      <Router>
        <Administrator />
        <Route exact path="/" component={CommonPage} />
       
      </Router>
    </div>
  );
}

export default App;

