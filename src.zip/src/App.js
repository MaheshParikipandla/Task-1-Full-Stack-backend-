import logo from "./logo.svg";
import "./App.css";
import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import CommonPage from "./components/common/CommonPage";
import Administrator from "./components/Administrator/Administrator";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import State from "./components/State";
import ReducerAction from "./components/Reducer";
import Effect from "./components/Effect";

import Ref from "./components/Ref";
import InputFocus from "./components/focus";
import { Home } from "./components2/Home"



import { Drawer, DrawerTab } from "./components2/Drawer";
import Navbarone, { Navbar } from "./components2/Navbar";
function App() {
  return (
    <div className="App">
      <Router>
      <Navbarone></Navbarone>
        {/* <Administrator ></Administrator> */}

        {/* <Route exact path="/" component={CommonPage} /> */}
        <Route exact path="/" component={Home} />
        <Route exact path="/newtab" component={DrawerTab} />

       
        
        
        {/* <Route exact path="/state" component={State} />
        <Route exact path="/Reducer" component={ReducerAction} />
        <Route exact path="/effect" component={Effect} />
        <Route exact path="/ref" component={Ref} />
         <Route exact path="/focus" component={InputFocus} /> */}
      </Router>
      <ToastContainer autoClose={2000}  />
    </div>
  );
}

export default App;
