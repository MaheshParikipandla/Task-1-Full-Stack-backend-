import react from "react";
import { Navbar } from "@blueprintjs/core";
import { Alignment } from "@blueprintjs/core";
import Book1 from "../assets/images/Book1.jpg";
import b4 from "../assets/images/b4.jpg";
import b5 from "../assets/images/b5.jpg";
import b7 from "../assets/images/b7.jpg";
import book2 from "../assets/images/book2.jpg";
import book3 from "../assets/images/book3.jpg";
import {
  Button,
  Card,
  Elevation,
  Drawer,
  Label,
  InputGroup,
} from "@blueprintjs/core";
import { Link } from "react-router-dom";

export const Home = () => {
  return (
    <div>
      <div class="table" style={{ margin: "20px" }}>
        <table>
          <tr>
            <th>
              <Card
                interactive={true}
                elevation={Elevation.TWO}
                style={{ width: "70%", height: "20%" }}
              >
                <img src={Book1} width="100%" height="20%" alt="" />
              </Card>
            </th>
            <th>
              <Card
                interactive={true}
                elevation={Elevation.TWO}
                style={{ width: "70%", height: "20%" }}
              >
                <img src={b4} width="100%" height="30%" alt="" />
              </Card>
            </th>
            <th>
              <Card
                interactive={true}
                elevation={Elevation.TWO}
                style={{ width: "70%", height: "20%" }}
              >
                <img src={b5} width="100%" height="20%" alt="" />
              </Card>
            </th>
            <th>
              <Card
                interactive={true}
                elevation={Elevation.TWO}
                style={{ width: "70%", height: "20%" }}
              >
                <img src={book3} width="100%" height="20%" alt="" />
              </Card>
            </th>
          </tr>
        </table>
      </div>
      <div class="table" style={{ margin: "20px" }}>
        <table>
          <tr>
            <th>
              <Card
                interactive={false}
                elevation={Elevation.TWO}
                style={{ width: "70%", height: "20%" }}
              >
                <img src={b4} width="100%" height="20%" alt="" />
                {/* <Button>Submit</Button> */}
              </Card>
            </th>
            <th>
              <Card
                interactive={false}
                elevation={Elevation.TWO}
                style={{ width: "70%", height: "20%" }}
              >
                <img src={b5} width="100%" height="20%" alt="" />
                {/* <Button>Submit</Button> */}
              </Card>
            </th>
            <th>
              <Card
                interactive={false}
                elevation={Elevation.TWO}
                style={{ width: "70%", height: "20%" }}
              >
                <img src={b7} width="100%" height="20%" alt="" />
              </Card>
            </th>
            <th>
              <Card
                interactive={false}
                elevation={Elevation.TWO}
                style={{ width: "70%", height: "20%" }}
              >
                <img src={book2} width="100%" height="20%" alt="" />
              </Card>
            </th>
          </tr>
        </table>
      </div>
    </div>
  );
};
// import React from "react";
// import { Navbar } from "@blueprintjs/core";
// import { Alignment } from "@blueprintjs/core";
// import { Button } from "@blueprintjs/core";
// import {  Callout, Classes, Popover, Switch } from "@blueprintjs/core";
// export const Home=() =>{
// return (
// <>
// <Navbar>
// <Navbar.Group align={Alignment.CENTER}>
// <Navbar.Divider />
// <Button className="bp4-minimal" text="Home" />
// <Button className="bp4-minimal" text="New" />
// <Button className="bp4-minimal" text="Category" />
// </Navbar.Group>
// </Navbar>
// </>
// );

// }
// // export default Home;
