import React from 'react';
import { useState } from "react";
import { toast } from "react-toastify";
import Drawer from 'react-modern-drawer';
import 'react-modern-drawer/dist/index.css'
import '@blueprintjs/core/lib/css/blueprint.css';
import { FaWindowClose } from "react-icons/fa";

export const DrawerTab = () => {
   const [isOpen, setIsOpen] = React.useState(false)
   const toggleDrawer = () => {
      setIsOpen((prevState) => !prevState)
   }
       
      const [name, setName] = useState('');
      const [category, setCategory] = useState('');
      const [subcategory, setSubcategory] = useState('');

      const handle = () => {
         localStorage.setItem('Name', name);
         localStorage.setItem('Category', category);
         localStorage.setItem('SubCategory', subcategory);
         toast.success("New Book is created Successfully");
      };
      const remove = () => {
         localStorage.removeItem('Name');
         localStorage.removeItem('Category');
         localStorage.removeItem('SubCategory');
         toast.success("Book is deleted Successfully");
      };

 
      return (
         <div >
            
            <div className='new' style={{marginLeft:"60px"}}>
               <h1>New </h1>
               <button onClick={toggleDrawer}>Create new Book</button> &nbsp;
               
                     <button onClick={remove}>Delete Book</button>
                  
                {localStorage.getItem('Name') && (
                  <div>
                     <h4>RECORDS CREATED</h4>
                        Name: <p>{localStorage.getItem('Name')}</p>
                     </div>
                  )}
                  {localStorage.getItem('Category') && (
                     <div>
                        Category: <p>{localStorage.getItem('Category')}</p>
                     </div>
                  )}
                  {localStorage.getItem('SubCategory') && (
                     <div>
                        SubCategory: <p>{localStorage.getItem('SubCategory')}</p>
                     </div>
                  )}
            </div>
            
            <Drawer
               open={isOpen}
               onClose={toggleDrawer}
               direction='right'
               size={700}px
               className='drawer'
            >
               <div style={{ paddingLeft: "600px" }}>
                  <button onClick={toggleDrawer}><FaWindowClose></FaWindowClose></button>
                   
                 </div>
               <div className='drawer-content' style={{paddingLeft:"20px"}}>
                  <h1>Name</h1>
                  <input
                     placeholder="Enter the name"
                     value={name}
                     onChange={(e) => setName(e.target.value)}
                  />
                  <h1>Category</h1>
                  <input
                     type="text"
                     placeholder="Enter the category"
                     value={category}
                     onChange={(e) => setCategory(e.target.value)}
                  />
                  <h1>Sub Category</h1>
                  <input type="text" placeholder='Enter the subcategory' value={subcategory} onChange={(e) => setSubcategory(e.target.value)}></input>
                  <br></br>
                  <div> <br></br>
                     <button onClick={handle}>Submit</button> &nbsp;
                     
           
                  </div><br></br>
                  
                  
               </div>
            </Drawer>
      
      
       
         </div>

      );

   }
// import React from 'react';
// import { useState } from "react";
// import { toast } from "react-toastify";
// import Drawer from 'react-modern-drawer';
// import 'react-modern-drawer/dist/index.css'
// import '@blueprintjs/core/lib/css/blueprint.css';
// import { FaWindowClose } from "react-icons/fa";

// export const DrawerTab = () => {
//    const [isNewDrawerOpen, setIsNewDrawerOpen] = React.useState({ isDrawerOpen: false})
//    const toggleDrawer = () => {
//       setIsOpen((prevState) => !prevState)
//    }
       
//       const [name, setName] = useState('');
//       const [category, setCategory] = useState('');
//       const [subcategory, setSubcategory] = useState('');

//       const handle = () => {
//          localStorage.setItem('Name', name);
//          localStorage.setItem('Category', category);
//          localStorage.setItem('SubCategory', subcategory);
//          toast.success("New Book is created Successfully");
//       };
//       const remove = () => {
//          localStorage.removeItem('Name');
//          localStorage.removeItem('Category');
//          localStorage.removeItem('SubCategory');
//          toast.success("Book is deleted Successfully");
//       };

 
//       return (
//          <div >
            
//             <div className='new' style={{marginLeft:"60px"}}>
//                <h1>New </h1>
//                <button onClick={toggleDrawer}>Create new Book</button> &nbsp;
               
//                      <button onClick={remove}>Delete Book</button>
                  
//                 {localStorage.getItem('Name') && (
//                   <div>
//                      <h4>RECORDS CREATED</h4>
//                         Name: <p>{localStorage.getItem('Name')}</p>
//                      </div>
//                   )}
//                   {localStorage.getItem('Category') && (
//                      <div>
//                         Category: <p>{localStorage.getItem('Category')}</p>
//                      </div>
//                   )}
//                   {localStorage.getItem('SubCategory') && (
//                      <div>
//                         SubCategory: <p>{localStorage.getItem('SubCategory')}</p>
//                      </div>
//                   )}
//             </div>
            
//             <Drawer
//                open={isOpen}
//                onClose={toggleDrawer}
//                direction='right'
//                size={700}px
//                className='drawer'
//             >
//                <div style={{ paddingLeft: "600px" }}>
//                   <button onClick={toggleDrawer}><FaWindowClose></FaWindowClose></button>
                   
//                  </div>
//                <div className='drawer-content' style={{paddingLeft:"20px"}}>
//                   <h1>Name</h1>
//                   <input
//                      placeholder="Enter the name"
//                      value={name}
//                      onChange={(e) => setName(e.target.value)}
//                   />
//                   <h1>Category</h1>
//                   <input
//                      type="text"
//                      placeholder="Enter the category"
//                      value={category}
//                      onChange={(e) => setCategory(e.target.value)}
//                   />
//                   <h1>Sub Category</h1>
//                   <input type="text" placeholder='Enter the subcategory' value={subcategory} onChange={(e) => setSubcategory(e.target.value)}></input>
//                   <br></br>
//                   <div> <br></br>
//                      <button onClick={handle}>Submit</button> &nbsp;
                     
           
//                   </div><br></br>
                  
                  
//                </div>
//             </Drawer>
      
      
       
//          </div>

//       );

//    }
