import react from "react";
import { Navbar } from "@blueprintjs/core";
import { Alignment } from "@blueprintjs/core";
import {
  Button,
  Card,
  Elevation,
  Drawer,
  Label,
  InputGroup,
} from "@blueprintjs/core";
import { Link } from "react-router-dom";

 const Navbarone = () => { 
    return (
        <div>
        <Navbar>
            <Navbar.Group >
                <Button className="bp4-minimal" > <Link to="/" >Home</Link></Button> &nbsp;
                <Button className="bp4-minimal" > <Link to="/newtab" >New</Link></Button> &nbsp;
                 <Button className="bp4-minimal"> <Link to="/" >Category</Link></Button> &nbsp;
            </Navbar.Group>
        </Navbar></div>
    );
}
export default Navbarone;