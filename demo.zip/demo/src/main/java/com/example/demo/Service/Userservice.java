package com.example.demo.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Users;
import com.example.demo.Repository.userrepo;

import java.util.List;


@Service
public class Userservice {

	@Autowired
	userrepo repo;
	

    public List<Users> getUsers() {

        List<Users> list=repo.findAll();

        return list;
    }
    
   
  

	

}
