package com.example.demo.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="assignedadmins")
public class Admins {
	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int id;
	private String Admin;
	private String Signin;
	
	
	public Admins() {}
	
    public Admins(int id,String Admin, String Signin) {
        
        this.id = id;
        this.Admin = Admin;
        this.Signin=Signin;
    }
    
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	public String getAdmin() {
		return Admin;
	}
	public void setAdmin(String admin) {
		Admin = admin;
	}
	public String getSignin() {
		return Signin;
	}
	public void setSignin(String signin) {
		Signin = signin;
	}
	@Override
	public String toString() {
		return "Admins [id=" + id + ", Admin=" + Admin + ", Signin=" + Signin + "]";
	}
	
	

}
