package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.Model.Users;

@Repository
public interface userrepo extends JpaRepository<Users,String> {
	
//	@Query("select p from role p join fetch p.role where p.role LIKE :prole%")
//	List<Users> getRolesListByName(@Param("prole")String pName);
//	@Query("select p from Products p join fetch p.category where p.productName LIKE :pName%")
//	List<Products> getProductListByName(@Param("pName")String pName);
}
