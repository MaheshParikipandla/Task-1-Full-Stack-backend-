package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="assignedadmins")
public class Admins {
	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int id;
	private String admin;
	private String Signin;
	
	
	
	
	
	
	
	
	
	public String getAdmin() {
		return admin;
	}

	public void setAdmin(String admin) {
		this.admin = admin;
	}


	public String getSignin() {
		return Signin;
	}


	public void setSignin(String signin) {
		Signin = signin;
	}

	
	
    
	
	
	

}
