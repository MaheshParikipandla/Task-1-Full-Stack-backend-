package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.ApplicationAccess;
import com.example.demo.Repository.AppsRepo;

@Service
public class AppsService {
	@Autowired
	AppsRepo appsrepo;
	 public List<ApplicationAccess> getApps() {

	        List<ApplicationAccess> list2=appsrepo.findAll();

	        return list2;
	    }

}
