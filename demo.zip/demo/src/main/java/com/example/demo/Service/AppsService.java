package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Bean.AdminsInputBean;
import com.example.demo.Bean.ApplicationAccessInputBean;
import com.example.demo.Controller.RolesController;
import com.example.demo.Repository.AppsRepo;
import com.example.demo.constants.LoggerMessage;
import com.example.demo.entity.Admins;
import com.example.demo.entity.ApplicationAccess;
import com.example.demo.entity.Users;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.DataAccessException;

@Service
public class AppsService {
	@Autowired
	AppsRepo appsrepo;

	public List<ApplicationAccess> getApps() {

		final Logger LOGGER = LoggerFactory.getLogger(AppsService.class);

		LOGGER.info("Entering ApplicationAccess Service method  .....");
		try {
			List<ApplicationAccessInputBean> appList = new ArrayList<>();

			List<ApplicationAccess> applist = appsrepo.findAll();

			for (ApplicationAccess app : applist) {
				ApplicationAccessInputBean appinputbean = new ApplicationAccessInputBean();
				appinputbean.setApps(app.getApps());

				appList.add(appinputbean);

			}
			LOGGER.info(LoggerMessage.SUCCESS_MESSAGE);
			return applist;
		} catch (BadRequestException e) {
			throw new BadRequestException(LoggerMessage.BAD_REQUEST, e);
		} catch (NullPointerException e) {
			throw new NullPointerException(LoggerMessage.GET_USER_ROLES_NULL_POINTER_EXCEPTION);
		}

	}

}
