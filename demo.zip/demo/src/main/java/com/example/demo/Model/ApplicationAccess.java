package com.example.demo.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="applicationacces")
public class ApplicationAccess {

	@Id
    @GeneratedValue(strategy= GenerationType.AUTO)
	private int id;
	private String Apps;
	
	public ApplicationAccess() {}
	
	 public ApplicationAccess(int id, String Apps) {
	       
	        this.id = id;
	        this.Apps = Apps;       
	    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getApps() {
		return Apps;
	}

	public void setApps(String apps) {
		Apps = apps;
	}

	@Override
	public String toString() {
		return "ApplicationAccess [id=" + id + ", Apps=" + Apps + "]";
	}
	 
	

	

	
}
