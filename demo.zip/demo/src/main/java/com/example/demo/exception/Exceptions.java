package com.example.demo.exception;


	public interface Exceptions {

	    public int BAD_REQUEST_EXCEPTION = 400;
	    public int UnauthorizedException = 401;
	    public int NotFoundException= 404;
	    public int InternalServerErrorException = 500;
	    
	    public String BAD_REQUEST_EXCEPTION_MESSAGE = "The request was unsuccessful.";
	    public String BAD_REQUEST_EXCEPTION_FOR_GET_EMPLOYEE_BY_ID_MESSAGE = "User not found with ID";

	    public String BAD_REQUEST_EXCEPTION_FOR_BLOCK_EMPLOYEE_BY_ID_MESSAGE = "User not found with ID to Block the user from Sign-in";

	    public String GLOBAL_EXCEPTION_MESSAGE = "Internal Server Error";

	    public String ACTIVE_EMPLOYEE_DETAILS_EXCEPTION_MESSAGE = "No Active user Details found";
	}



