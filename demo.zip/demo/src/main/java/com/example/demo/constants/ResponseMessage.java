package com.example.demo.constants;

public class ResponseMessage {
	 public static int SUCCESS = 200;
	    public int INPUT_DATA_NOT_VALID = 400;
	    public int SERVER_ERROR = 500;

	    
	    public static String SUCCESS_MESSAGE = "The request was successful.";
	    
	    public String ERROR_MESSAGE = "The input data was not valid.";
	    
	   

}
