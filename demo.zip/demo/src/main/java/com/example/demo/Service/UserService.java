package com.example.demo.Service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Bean.UsersInputBean;
import com.example.demo.Repository.UserRepo;
import com.example.demo.constants.LoggerMessage;
import com.example.demo.constants.ResponseMessage;
import com.example.demo.entity.Users;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.DataAccessException;
import com.example.demo.exception.ResponseData;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

	@Autowired
	UserRepo repo;

	public List<Users> getUsers() throws BadRequestException {
		final Logger LOGGER = LoggerFactory.getLogger(UserService.class);
		LOGGER.info("Entering User Roles method");
		LOGGER.info("Entering User Service method  .....");
		try {

			List<UsersInputBean> userList = new ArrayList<>();

			List<Users> users = repo.findAll();
//            if cond
			for (Users user : users) {
				UsersInputBean userinputbean = new UsersInputBean();
				userinputbean.setRole(user.getRole());
				userinputbean.setDescription(user.getDescription());
				userList.add(userinputbean);
			}
			LOGGER.info(LoggerMessage.SUCCESS_MESSAGE);
			return users;
		} catch (BadRequestException e) {
			throw new BadRequestException(LoggerMessage.BAD_REQUEST, e);
		} catch (NullPointerException e) {
			throw new NullPointerException(LoggerMessage.GET_USER_ROLES_NULL_POINTER_EXCEPTION);
		}

	}

	public Users getUserByRole(String role) {
		try {
			Users user = repo.findByRole(role);
			return user;
		} catch (BadRequestException e) {
			throw new BadRequestException(LoggerMessage.BAD_REQUEST, e);
		} catch (NullPointerException e) {
			throw new NullPointerException(LoggerMessage.GET_USER_ROLES_NULL_POINTER_EXCEPTION);
		}

	}

}
