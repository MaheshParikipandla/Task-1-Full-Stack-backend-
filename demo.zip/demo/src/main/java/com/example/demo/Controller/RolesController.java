package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.Admins;
import com.example.demo.Model.ApplicationAccess;
import com.example.demo.Model.Users;
import com.example.demo.Service.AdminService;
import com.example.demo.Service.AppsService;
import com.example.demo.Service.Userservice;

	@RestController
	@CrossOrigin(origins="http://localhost:3000")
	public class RolesController {
	    @Autowired
	    Userservice uservice;
	    @Autowired
	    AppsService apps;
	    
	    @Autowired
	    AdminService admin;
	    
	    @GetMapping( value = "/Userroles" ,produces = MediaType.APPLICATION_JSON_VALUE )
	    public ResponseEntity<List<Users>> getUsers()
	    {
	        List<Users> list=uservice.getUsers();
	        return new ResponseEntity<List<Users>>(list,HttpStatus.CREATED);
	    }
	    
	    @GetMapping( value = "/AssignedAdmins" ,produces = MediaType.APPLICATION_JSON_VALUE )
	    public ResponseEntity<List<Admins>> getAdmin()
	    {
	        List<Admins> list=admin.getAdmin();
	        return new ResponseEntity<List<Admins>>(list,HttpStatus.CREATED);
	    }
	    
	    @GetMapping( value = "/ApplicationAccess" ,produces = MediaType.APPLICATION_JSON_VALUE )
	    public ResponseEntity<List<ApplicationAccess>> getApps()
	    {
	        List<ApplicationAccess> list=apps.getApps();
	        return new ResponseEntity<List<ApplicationAccess>>(list,HttpStatus.CREATED);
	    }
	   


	
	   

	}
