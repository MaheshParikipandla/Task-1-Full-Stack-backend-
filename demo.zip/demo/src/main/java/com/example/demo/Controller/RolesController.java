package com.example.demo.Controller;

import org.springframework.http.HttpStatus;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Repository.UserRepo;

import com.example.demo.Service.UserService;
import com.example.demo.constants.LoggerMessage;
import com.example.demo.constants.URLConstants;

import com.example.demo.entity.Users;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.DataAccessException;

@RestController
@CrossOrigin(origins = { URLConstants.CROSS_ORIGIN_URL })
public class RolesController {

	private static final Logger LOGGER = LoggerFactory.getLogger(RolesController.class);
	@Autowired
	UserService userservice;

	@Autowired
	UserRepo repo;

	@GetMapping(value = { URLConstants.USER_ROLES_URL }, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Users>> getUsers() throws BadRequestException, DataAccessException {

		
		LOGGER.info("Entering Get User roles controller   .....");

		try {
			List<Users> list = userservice.getUsers();
			LOGGER.info(LoggerMessage.SUCCESS_MESSAGE);
			LOGGER.info(LoggerMessage.SUCCESSFULLY_FETCHED_USERS_MSG);
			return new ResponseEntity<List<Users>>(list, HttpStatus.OK);

		} catch (BadRequestException e) {
			throw new BadRequestException(LoggerMessage.BAD_REQUEST, e);
		} catch (NullPointerException e) {
			throw new NullPointerException(LoggerMessage.USER_ROLES_NULL_POINTER_EXCEPTION);
		}

	}

	@GetMapping(URLConstants.SPECIFIC_USER_ROLES_URL)
	public Users getUserByRole(@PathVariable String role) throws BadRequestException {
		LOGGER.info("Entering Get User By Role  method  .....");
		try {
			LOGGER.info("User role Apps data is displayed");
			Users user = userservice.getUserByRole(role);
			System.out.print(role);
			LOGGER.info(LoggerMessage.SUCCESS_MESSAGE);
			
			return user;
		}

		catch (BadRequestException e) {
			throw new BadRequestException(LoggerMessage.BAD_REQUEST, role);
		} catch (NullPointerException e) {
			throw new NullPointerException(LoggerMessage.GET_USER_ROLES_NULL_POINTER_EXCEPTION);
		}

	}

}
