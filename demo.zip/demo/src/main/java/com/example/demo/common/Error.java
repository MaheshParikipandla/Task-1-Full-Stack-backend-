package com.example.demo.common;

public class Error {
	
	

	public Error() {}
	
	public Error(String target, String message) {
		super();
		this.target = target;
		this.message = message;
	}
	 private String target;
	    private String message;
		public String getTarget() {
			return target;
		}
		public void setTarget(String target) {
			this.target = target;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		
		@Override
		public String toString() {
			return "Error [target=" + target + ", message=" + message + "]";
		}
}
