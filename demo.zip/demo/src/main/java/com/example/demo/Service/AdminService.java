package com.example.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.Admins;
import com.example.demo.Model.Users;
import com.example.demo.Repository.AdminsRepo;
import com.example.demo.Repository.userrepo;


@Service
public class AdminService {

	@Autowired
	AdminsRepo adminrepo;
	

    public List<Admins> getAdmin() {

        List<Admins> list=adminrepo.findAll();

        return list;
    }
    
   
  

	

}