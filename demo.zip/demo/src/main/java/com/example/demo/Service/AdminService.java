package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Bean.AdminsInputBean;
import com.example.demo.Bean.UsersInputBean;
import com.example.demo.Repository.AdminsRepo;
import com.example.demo.Repository.UserRepo;
import com.example.demo.constants.LoggerMessage;
import com.example.demo.entity.Admins;
import com.example.demo.entity.Users;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.DataAccessException;

@Service
public class AdminService {

	@Autowired
	AdminsRepo adminrepo;

	public List<Admins> getAdmin() {
		final Logger LOGGER = LoggerFactory.getLogger(AdminService.class);

		LOGGER.info("Entering Admin Service method  .....");

		try {
			List<AdminsInputBean> adminList = new ArrayList<>();

			List<Admins> adminobj = adminrepo.findAll();
			if (adminobj.isEmpty()) {
				return null;
			}

			for (Admins ad : adminobj) {
				AdminsInputBean admininputbean = new AdminsInputBean();
				admininputbean.setAdmin(ad.getAdmin());
				admininputbean.setSignin(ad.getSignin());
				adminList.add(admininputbean);

			}
			LOGGER.info(LoggerMessage.SUCCESS_MESSAGE);
			return adminobj;
		} catch (BadRequestException e) {
			throw new BadRequestException(LoggerMessage.BAD_REQUEST, e);
		} catch (NullPointerException e) {
			throw new NullPointerException(LoggerMessage.GET_USER_ROLES_NULL_POINTER_EXCEPTION);
		}
	}

}