
import { logger, fileAsyncTransport } from "react-native-logs";
import RNFS from "react-native-fs";

// require the module
// var RNFS = require('react-native-fs');
var path = RNFS.DocumentDirectoryPath + '/test.txt';

let today = new Date();
let date = today.getDate();
let month = today.getMonth() + 1;
let year = today.getFullYear();

const config = {
  severity: "debug",
  transport: fileAsyncTransport,
  transportOptions: {
    FS: RNFS,
    fileName: `logs_${date}-${month}-${year}`, 
  },
};
export default config;


// import { logger, consoleTransport } from "react-native-logs";
// import RNFS from "react-native-fs";
// // import { fileAsyncTransport } from "react-native-logs";
// let today = new Date();
// let date = today.getDate();
// let month = today.getMonth() + 1;
// let year = today.getFullYear();
// const defaultConfig = {
    
//   levels: {
//     debug: 0,
//     info: 1,
//     warn: 2,
//     error: 3,
//   },
//   severity: "debug",
//     transport: consoleTransport,
// //   transport: fileAsyncTransport,
//   transportOptions: {
//     colors: {
//       info: "blueBright",
//       warn: "yellowBright",
//           error: "redBright",
      
//     },
//   },
//   async: true,
//   dateFormat: "time",
//   printLevel: true,
//   printDate: true,
//   enabled: true,
// };
//  export default defaultConfig;

// import { logger, fileAsyncTransport } from "react-native-logs";
// import RNFS from "react-native-fs";

//  const config = {
//   transport: fileAsyncTransport,
//   transportOptions: {
//     FS: RNFS,
//     fileName: `log.txt`
//   },
// };
// export default config;



