import logo from "./logo.svg";
import "./App.css";
import React from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import CommonPage from "./components/common/CommonPage";
import Administrator from "./components/Administrator/Administrator";
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import State from "./components/State";
import ReducerAction from "./components/Reducer";
function App() {
  return (
    <div className="App">
      <Router>
        <Administrator ></Administrator>

        <Route exact path="/" component={CommonPage} />
        <Route exact path="/state" component={State} />
         <Route exact path="/Reducer" component={ReducerAction} />
      </Router>
      <ToastContainer autoClose={2000}  />
    </div>
  );
}

export default App;
