// import { logger, fileAsyncTransport } from "react-native-logs";
// import RNFS from "react-native-fs";
// /* EXPO:
//  * import * as FileSystem from 'expo-file-system';
//  */

// let today = new Date();
// let date = today.getDate();
// let month = today.getMonth() + 1;
// let year = today.getFullYear();

// const config = {
//   severity: "debug",
//   transport: fileAsyncTransport,
//   transportOptions: {
//     FS: RNFS,
//     /* EXPO:
//      * FS: FileSystem,
//      */
//     fileName: `logs_${date}-${month}-${year}`, // Create a new file every day
//   },
// };
// export default config;

// import { logger, fileAsyncTransport } from "react-native-logs";
// import RNFS from "react-native-fs";

//  const config = {
//   transport: fileAsyncTransport,
//   transportOptions: {
//     FS: RNFS,
//     fileName: `log.txt`,
//   },
// };
// export default config;


// // import { logger } from "react-native-logs";

// // var log = logger.createLogger();

// // log.debug("This is a Debug log");
// // log.info("This is an Info log");
// // log.warn("This is a Warning log");
// // log.error("This is an Error log");


// // const log4js = () => {
// //   var log4js = require('log4js');
// //   log4js.configure({
// //     appenders: [
// //       { type: 'console' },
// //       { type: 'file', filename: 'logs/cheese.log', category: 'cheese' }
// //     ]
// //   });
// // }