import React from "react";
import ReactDOM from "react-dom";
import renderer from "react-test-renderer";
import { toHaveStyle } from "@testing-library/jest-dom";
import { render, screen, fireEvent } from "@testing-library/react";
import "jest-styled-components";
import RoleGroups from "../RoleGroups";
import "@testing-library/jest-dom/extend-expect";

import axios from 'axios';
import { waitFor } from '@testing-library/react';


jest.mock('axios');

const fakeUsers = [{
  "id": 1,
  "role": "Test User 1",
  "description": "testuser1",
 }, {
  "id": 2,
  "role": "Test User 2",
  "description": "testuser2",
 }];

describe('Rolegroup component', () => {
 test('it renders', async () => {
   axios.get.mockResolvedValue({ data: fakeUsers });
   render(<RoleGroups />);
   expect(screen.getByText('Roles')).toBeInTheDocument();
 });

 test('it displays a list of users', async () => {
   axios.get.mockResolvedValue({ data: fakeUsers });

   render(<RoleGroups />);

   const userList = await waitFor(() => screen.getByText('Roles'));
   expect(userList).toBeInTheDocument();
 });

});




it("renders without crashing", () => {
  const div = document.createElement("div");
  ReactDOM.render(<RoleGroups />, div);
});

test("render user role  data element", () => {
  render(<RoleGroups />);
  expect(screen.getByText("User roles")).toBeInTheDocument();
});
test("render Description data element", () => {
  render(<RoleGroups />);
  expect(screen.getByText("Description")).toBeInTheDocument();
});
test("render Roles element", () => {
  render(<RoleGroups />);

  expect(screen.getByText("Roles")).toBeInTheDocument();
});

 <button data-testid="userroles" style="background-color: ededed"></button>
it("render table", () => {
  const { getByTestId } = render(<RoleGroups />);

  const input = getByTestId("table");

  expect(input).toBeTruthy();
});
it("render thead", () => {
  const { getByTestId } = render(<RoleGroups />);

  const input = getByTestId("thead");

  expect(input).toBeTruthy();
});
it("render tbody", () => {
  const { getByTestId } = render(<RoleGroups />);

  const input = getByTestId("tbody");

  expect(input).toBeTruthy();
});

it("initially description text content", () => {
  const { getByTestId } = render(<RoleGroups />);

  expect(getByTestId("description")).toHaveTextContent(/^Description$/); // to match the whole content
  expect(getByTestId("description")).toHaveTextContent(/description$/i); // to use case-insensitive match
  expect(getByTestId("description")).not.toHaveTextContent("h");
});

it("check css properties of description", () => {
  const { getByTestId } = render(<RoleGroups />);
  expect(getByTestId("description")).toHaveStyle(`
  font-size: 13px;
   font-weight: bold;
`);
});

it("check css properties of adddel", () => {
  const { getByTestId } = render(<RoleGroups />);
  expect(getByTestId("adddel")).toHaveStyle(`
  font-size: 13px;
  font-weight: lighter;
`);
});

it("check css properties of roles", () => {
  const { getByTestId } = render(<RoleGroups />);
  expect(getByTestId("roles")).toHaveStyle(`
  font-size: 20px;
  font-weight:bold;
`);
});

it("check css properties of innerloc", () => {
  const { getByTestId } = render(<RoleGroups />);
  expect(getByTestId("innerloc")).toHaveStyle(`
  padding-top:20px;
  font-size: 12px;
  font-weight: lighter;
`);
});

it("check color of circle slash icon", () => {
  const { getByTestId } = render(<RoleGroups />);
  expect(getByTestId("circleslash")).toHaveStyle(`
  color:blue;
`);
});

it("check css properties of AddRole", () => {
  const { getByTestId } = render(<RoleGroups />);
  expect(getByTestId("AddRole")).toHaveStyle(`
  color:rgb(240, 236, 236);
`);
});

it("check css properties of VsAccount icon", () => {
  const { getByTestId } = render(<RoleGroups />);
  expect(getByTestId("VsAccount")).toHaveStyle(`
  color:blue;
`);
});

it("check css properties of userrole ", () => {
  const { getByTestId } = render(<RoleGroups />);
  expect(getByTestId("userrole")).toHaveStyle(`
  font-weight: lighter;
  padding-left: 50px;
  font-size: 13px;
`);
});

