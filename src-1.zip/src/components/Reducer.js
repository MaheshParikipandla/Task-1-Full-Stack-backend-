import React, { useReducer } from "react";

const Reducer = (state, action) => {
  switch (action.type) {
    case "INCREMENT":
      return { count: state.count + 1, text: state.text };
    case "ToggleText":
      return { count: state.count, text: !state.text };
    default:
      return state;
  }
};

const ReducerAction = () => {
  const [state, dispatch] = useReducer(Reducer, { count: 0, text: true });

  return (
    <div>
      {state.count}
      <br></br>
      <button
        onClick={() => {
          dispatch({ type: "INCREMENT" });
          dispatch({ type: "ToggleText" });
        }}
      >
        {" "}
        click here{" "}
      </button>
      <br></br>
      {state.text && <p>Mahesh</p>}
    </div>
  );
};
export default ReducerAction;
