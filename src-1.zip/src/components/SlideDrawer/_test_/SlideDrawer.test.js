
import React from 'react';
import ReactDOM from 'react-dom';
import "@testing-library/jest-dom/extend-expect";
import { render,screen } from '@testing-library/react'
import SlideDrawer from '../SlideDrawer';

it("renders without crashing", () => {
    const div = document.createElement("div");
    ReactDOM.render(<SlideDrawer />, div)
})
it("renders properly at left corner of the page", () => {
    const { getByTestId } = render(<SlideDrawer />)
    expect(getByTestId('window')).toBeVisible(<SlideDrawer />)
})
test('render Assigned Admins element', () => {
  render(<SlideDrawer />);
  expect(screen.getByText('Assigned Admins')).toBeInTheDocument();
});
test('render Application Access element', () => {
  render(<SlideDrawer />);
  expect(screen.getByText('Application Access')).toBeInTheDocument();
});
it("check css properties of description", () => {
  const { getByTestId } = render(<SlideDrawer />);
  expect(getByTestId("col1")).toHaveStyle(`
  padding-left:20px;
`);
});

it("check css properties of description", () => {
  const { getByTestId } = render(<SlideDrawer />);
  expect(getByTestId("col2")).toHaveStyle(`
  padding-right:100px;
`);
});

