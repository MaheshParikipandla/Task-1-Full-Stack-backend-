// import React, { Component } from "react";
// import "./Administrator.css";
// import a from "../../assets/images/a.png";
// import { FaSearch, FaUser } from "react-icons/fa";

// // class Administrator extends Component {
// //   constructor(props) {
// //     super(props);
// //     this.state = {};
// //   }
// //   render() {

//     const Administrator = (topnav) => {
//     return (
//       <div className="rows">
//         <div className="topnav">
//           <a className="navbar-brand" href="" style={{ paddingLeft: "10px" }}>
//             <img src={a} width="50" height="40" />
//           </a>
//           <div className="admin">
//             <a>
//               <p className="pt-3">
//                 <h6> {topnav}</h6>
//               </p>
//             </a>
//           </div>
//           <a>
//             <i id="icon" className="fa fa-user ms-auto" aria-hidden="true"></i>
//           </a>
//           <div className="usericon">
//             <p>
//               <FaUser style={{ fontWeight: "bolder" }}></FaUser>
//             </p>
//           </div>
//         </div>
//       </div>
//     );
//   }

// export default Administrator;
import React, { Component } from "react";
import "./Administrator.css";
import a from "../../assets/images/a.png";
import {  FaUser } from "react-icons/fa";

const Administrator  = (topnav) =>  {
  

    return (
      <div data-testid="topnav">
    
      <div className="rows">
        <div className="topnav">
          <a className="navbar-brand"  data-testid="adminnav" style={{ paddingLeft: "10px",float:"left" }}>
            <img data-testid="adminimage" src={a} width="50" height="40" alt="administrator" />
          </a>
          <div className="admin">
            <a>
              <p className="pt-3" data-testid="adminleft" style={{fontSize:"15px"}}>
                  <h6>ADMINISTRATION</h6>
                
              </p>
            </a>
          </div>
          <a>
            <i id="icon" className="fa fa-user ms-auto" aria-hidden="true"></i>
          </a>
          <div className="usericon">
            <p>
              <FaUser style={{ fontWeight: "bolder" }}></FaUser>
            </p>
          </div>
        </div>
      </div>
        
       

     

        </div>
    );
  
}
export default Administrator;
