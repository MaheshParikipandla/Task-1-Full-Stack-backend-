import React, { useState } from "react";
const State = () => {
    const [counter, setCounter] = useState(0);
    const [Text, setText] = useState("mahesh");
    console.log(counter);
    console.log(Text);
    let onChange = (event) => {
       const newText = event.target.value;
        setText(newText);
    }
    return (
        <div>          
            {/* onclick */}
            <button onClick={() => setCounter(counter + 1)}>Increment  {counter}</button><br></br> 
            {/* onchange */}
            <input placeholder="enter any text" onChange={onChange} />
            {Text}
        </div>
    );    
}
export default State;